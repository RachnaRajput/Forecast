


<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8"/>
   
    </head>
<body>
 

                     
  
    <script type="text/javascript">
        function check_fields()
        {
            var street_add = false;
            var city1 = false;
           // var state1 = false;
            var space = "";
            if ( document.forecast.address.value != space)
            {              street_add = true;
         
//            else
//                alert("empty address");
               
             //document.forecast.address.value;
         //   validation();
            }
            if (document.forecast.city.value != space)
            city1 = true;
            //document.forecast.city.value;
           //  validation1();
            //if (document.forecast.state.value.sta != state1)
            if (document.getElementsByName("state")[0].value=="Sta")   
            {alert("select the state");
                     return false;
            }
             //state1 = true;
            if (street_add && city1 )
            { var add = document.getElementsByName("address")[0].value;
             
            var city_name = document.getElementsByName("city")[0].value;
             
             var state_name =document.getElementsByName("state")[0].value;
             //location.reload();
             
          //  var address1 = document.write(add +","+city_name+","+state_name);
             //hp
               // echo address1;
                 //  ?>
            //document.write(city_name);
             
            }
             
            else
            { if(!street_add ||(/[/\s/g ]/.test(street_add)))
                //|| (/[/\s/g ]/.test(add))){
                 alert("Please enter the value for Street Address");
            //}
             //if(street_add.value.match(/\s/g))
            //if(!(/[/\s/g ]/.test(street_add)))
              
                 
            // if(!(/s[^\t\n\r]/.test(street_add)))
                   // alert("empty");
              //alert("empty street address");
            
            if(!city1)
                alert("Please enter the value for City");
             
             return false;
            
            }
       
        }
        
 function myFunction() 
           
        {
            
         document.getElementsByName("address")[0].value = "";
          
         document.getElementsByName("city")[0].value = "";
           document.getElementsByName("state")[0].value = "Sta";
            document.getElementsByName("degree")[0].checked = true;
     document.getElementById("big_div").innerHTML = "";       
            
        }
       
    </script>
  <h1 align="center"> Forecast Search</h1>
<div align="center">
    <div align="center" style = "border:5px solid black; width: 500px;">


    <form id="myform" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" name= "forecast" method="post">
        <table>
            <tr><th align="left">
                Street Address:* </th>
                <td><input type="text" name="address" value="<?php echo isset($_POST["address"]) ?
$_POST["address"] : "" ?>" ><br></td>
            </tr>
        <tr>
                <th align="left">City:*</th>
                <td><input type="text" name="city" value="<?php echo isset($_POST["city"]) ?
$_POST["city"] : "" ?>" ><br></td>
            </tr>
            <tr><th align="left">
<!--State:* <input type="selected" name="state">-->
    State:*</th>
                <td><select name="state">
             
   
   <option  value="Sta">Select your state</option>
    <option value="AL"<?php if(isset($_POST['state'])&&$_POST['state']=="AL") echo "selected";?>>Alabama</option>
	<option value="AK"<?php if(isset($_POST['state'])&&$_POST['state']=="AK") echo "selected";?>>Alaska</option>
	<option value="AZ"<?php if(isset($_POST['state'])&&$_POST['state']=="AZ") echo "selected";?>>Arizona</option>
	<option value="AR"<?php if(isset($_POST['state'])&&$_POST['state']=="AR") echo "selected";?>>Arkansas</option>
	<option value="CA"<?php if(isset($_POST['state'])&&$_POST['state']=="CA") echo "selected";?>>California</option>
	<option value="CO"<?php if(isset($_POST['state'])&&$_POST['state']=="CO") echo "selected";?>>Colorado</option>
	<option value="CT"<?php if(isset($_POST['state'])&&$_POST['state']=="CT") echo "selected";?>>Connecticut</option>
	<option value="DE"<?php if(isset($_POST['state'])&&$_POST['state']=="DE") echo "selected";?>>Delaware</option>
	<option value="DC"<?php if(isset($_POST['state'])&&$_POST['state']=="DC") echo "selected";?>>District Of Columbia</option>
	<option value="FL"<?php if(isset($_POST['state'])&&$_POST['state']=="FL") echo "selected";?>>Florida</option>
	<option value="GA"<?php if(isset($_POST['state'])&&$_POST['state']=="GA") echo "selected";?>>Georgia</option>
	<option value="HI"<?php if(isset($_POST['state'])&&$_POST['state']=="HI") echo "selected";?>>Hawaii</option>
	<option value="ID"<?php if(isset($_POST['state'])&&$_POST['state']=="ID") echo "selected";?>>Idaho</option>
	<option value="IL"<?php if(isset($_POST['state'])&&$_POST['state']=="IL") echo "selected";?>>Illinois</option>
	<option value="IN"<?php if(isset($_POST['state'])&&$_POST['state']=="IN") echo "selected";?>>Indiana</option>
	<option value="IA"<?php if(isset($_POST['state'])&&$_POST['state']=="IA") echo "selected";?>>Iowa</option>
	<option value="KS"<?php if(isset($_POST['state'])&&$_POST['state']=="KS") echo "selected";?>>Kansas</option>
	<option value="KY"<?php if(isset($_POST['state'])&&$_POST['state']=="KY") echo "selected";?>>Kentucky</option>
	<option value="LA"<?php if(isset($_POST['state'])&&$_POST['state']=="LA") echo "selected";?>>Louisiana</option>
	<option value="ME"<?php if(isset($_POST['state'])&&$_POST['state']=="ME") echo "selected";?>>Maine</option>
	<option value="MD"<?php if(isset($_POST['state'])&&$_POST['state']=="MD") echo "selected";?>>Maryland</option>
	<option value="MA"<?php if(isset($_POST['state'])&&$_POST['state']=="MA") echo "selected";?>>Massachusetts</option>
	<option value="MI"<?php if(isset($_POST['state'])&&$_POST['state']=="MI") echo "selected";?>>Michigan</option>
	<option value="MN"<?php if(isset($_POST['state'])&&$_POST['state']=="MN") echo "selected";?>>Minnesota</option>
	<option value="MS"<?php if(isset($_POST['state'])&&$_POST['state']=="MS") echo "selected";?>>Mississippi</option>
	<option value="MO"<?php if(isset($_POST['state'])&&$_POST['state']=="MO") echo "selected";?>>Missouri</option>
	<option value="MT"<?php if(isset($_POST['state'])&&$_POST['state']=="MT") echo "selected";?>>Montana</option>
	<option value="NE"<?php if(isset($_POST['state'])&&$_POST['state']=="NE") echo "selected";?>>Nebraska</option>
	<option value="NV"<?php if(isset($_POST['state'])&&$_POST['state']=="NV") echo "selected";?>>Nevada</option>
	<option value="NH"<?php if(isset($_POST['state'])&&$_POST['state']=="NH") echo "selected";?>>New Hampshire</option>
	<option value="NJ"<?php if(isset($_POST['state'])&&$_POST['state']=="NJ") echo "selected";?>>New Jersey</option>
	<option value="NM"<?php if(isset($_POST['state'])&&$_POST['state']=="NM") echo "selected";?>>New Mexico</option>
	<option value="NY"<?php if(isset($_POST['state'])&&$_POST['state']=="NY") echo "selected";?>>New York</option>
	<option value="NC"<?php if(isset($_POST['state'])&&$_POST['state']=="NC") echo "selected";?>>North Carolina</option>
	<option value="ND"<?php if(isset($_POST['state'])&&$_POST['state']=="ND") echo "selected";?>>North Dakota</option>
	<option value="OH"<?php if(isset($_POST['state'])&&$_POST['state']=="OH") echo "selected";?>>Ohio</option>
	<option value="OK"<?php if(isset($_POST['state'])&&$_POST['state']=="OK") echo "selected";?>>Oklahoma</option>
	<option value="OR"<?php if(isset($_POST['state'])&&$_POST['state']=="OR") echo "selected";?>>Oregon</option>
	<option value="PA"<?php if(isset($_POST['state'])&&$_POST['state']=="PA") echo "selected";?>>Pennsylvania</option>
	<option value="RI"<?php if(isset($_POST['state'])&&$_POST['state']=="RI") echo "selected";?>>Rhode Island</option>
	<option value="SC"<?php if(isset($_POST['state'])&&$_POST['state']=="SC") echo "selected";?>>South Carolina</option>
	<option value="SD"<?php if(isset($_POST['state'])&&$_POST['state']=="SD") echo "selected";?>>South Dakota</option>
	<option value="TN"<?php if(isset($_POST['state'])&&$_POST['state']=="TN") echo "selected";?>>Tennessee</option>
	<option value="TX"<?php if(isset($_POST['state'])&&$_POST['state']=="TX") echo "selected";?>>Texas</option>
	<option value="UT"<?php if(isset($_POST['state'])&&$_POST['state']=="UT") echo "selected";?>>Utah</option>
	<option value="VT"<?php if(isset($_POST['state'])&&$_POST['state']=="VT") echo "selected";?>>Vermont</option>
	<option value="VA"<?php if(isset($_POST['state'])&&$_POST['state']=="VA") echo "selected";?>>Virginia</option>
	<option value="WA"<?php if(isset($_POST['state'])&&$_POST['state']=="WA") echo "selected";?>>Washington</option>
	<option value="WV"<?php if(isset($_POST['state'])&&$_POST['state']=="WV") echo "selected";?>>West Virginia</option>
	<option value="WI"<?php if(isset($_POST['state'])&&$_POST['state']=="WI") echo "selected";?>>Wisconsin</option>
	<option value="WY"<?php if(isset($_POST['state'])&&$_POST['state']=="WY") echo "selected";?>>Wyoming</option>
</select><br>
              </td> </tr>
            
            <tr>
                <th align="left">
                    Degree:*</th>
                
                
                
                <td><input type="Radio" name="degree" <?php if (isset($_POST['degree']) && $_POST['degree']=="us") echo "checked";?> value="us" checked>Fahrenheit
                    <input type="Radio" name="degree" <?php if (isset($_POST['degree']) && $_POST['degree']=="si") echo "checked";?> value="si"
                         >Celsius<br>  
                </td>   </tr>
<!--
            <tr>
                <td>
                *-Mandatory fields <br>
                </td>
            </tr>
-->
       <!-- <input type="submit" value="Search" onsubmit= check_fields() />
       <input type="submit" value="Clear" />-->
      <tr>
          <td></td>
          <td>
<input type="submit" value="Search" name="Search" onclick=" return check_fields()">
<input type="button" value="clear" name="clear" onclick="myFunction()"> <br> 
          </td> </tr>
             <tr>
                <td>
                *-Mandatory fields <br>
                </td>
            </tr>
            <tr>
                <td></td>
                <td align="left">
        <a href="http://forecast.io/">Powered by Forecast.io</a>
                </td>
            </tr>
        </table>
            </form>
        
    </div>
    </div>

<div id= "big_div">

        
  <?php
if(isset($_POST['address']) && isset($_POST['city']) && isset($_POST['state'])) { ?>

   <?php
        $addr= $_POST["address"];
       
 $cit= $_POST["city"];
       
 $state_name= $_POST["state"];
$unit = $_POST["degree"];
      
$array = Array($addr, $cit, $state_name);
$complete = join (',',$array);
//echo $complete. "<br>";
$complete = urlencode($complete);

//$request_url = "https://maps.google.com/maps/api/geocode/xml?address={$complete}";
$request_url = "https://maps.google.com/maps/api/geocode/xml?address={$complete}&key=AIzaSyAKo-narLstwWww0Nh7NreRp2jAKDZUOPA";

$parsed_url = parse_url($request_url);
//print_r($parsed_url);
//echo "<br>";
//echo "https://maps.google.com/maps/api/geocode/xml?address={$complete}&key=AIzaSyAKo-narLstwWww0Nh7NreRp2jAKDZUOPA";
$xml = new DOMDocument();
$xml = simplexml_load_file($request_url) or die("feed not loading");

//print $xml->saveXML();
//echo "<br>";

$lat = $xml['results'][0]['geometry']['location']['lat'];
$long = $xml['results'][0]['geometry']['location']['lng'];
//$lati= $xml->result->geometry->location->lat. "<br>";
//$longi= $xml->result->geometry->location->lng. "<br>";
$lati= $xml->result->geometry->location->lat or die("latitude not found");
//"<br>";
$longi= $xml->result->geometry->location->lng or die("longitude not found");
//"<br>";
//echo $lat;
//print "lng: " . $xml->result->geometry->location->lng. "<br>";
//print "lat: " . $xml->result->geometry->location->lat. "<br>";


//https://api.forecast.io/forecast/YOUR_APIKEY/LATITUDE,LONGITUDE?units=units_value&exclude=flags
$request_url1 = "https://api.forecast.io/forecast/f544b15e9df2da153c92691a80bc49cc/$lati,$longi?units=$unit&exclude=flag";
//echo "https://api.forecast.io/forecast/f544b15e9df2da153c92691a80bc49cc/{$lati},{$longi}?,units={$unit}&exclude=flag <br>";
//echo "<br>https://api.forecast.io/forecast/f544b15e9df2da153c92691a80bc49cc/$lati,$longi?units=$unit&exclude=flag";
//echo "<br>$request_url1<br>";
$parsed_url1 = parse_url($request_url1);
//print_r($parsed_url1);


 
  $resp_json = file_get_contents($request_url1);

 // decode the json
    $resp1 = json_decode($resp_json, true);
 //$resp1 = json_decode($resp_json);
//echo "$output <br>";
//echo "$resp1 <br>";
//echo "<br><pre>";
//print_r($resp1);
//echo "</pre>";
//$lat = $xml['results'][0]['geometry']['location']['lat'];
//$long = $xml['results'][0]['geometry']['location']['lng'];

// $lati = $resp['results'][0]['geometry']['location']['lat'];
$sum = $resp1['currently']['summary'];
//echo "summary: $sum<br>";
$temp = $resp1['currently']['temperature'];
    $temp_int= intval($temp);
//if($unit == 'us')
  // echo "Temperature: $temp F<br>";
//else
  //  echo"Temperature: $temp C<br>";
$ico = $resp1['currently']['icon'];



$preci = $resp1['currently']['precipIntensity'];
$preci1 = $preci/25.4;
    
$chance_of_rain = $resp1['currently']['precipProbability'];
//echo "precipProbability: ";
$rain_percent = $chance_of_rain *100;
//echo "$rain_percent%<br>";
$wind_speed = $resp1['currently']['windSpeed'];
//echo "Wind:";
$wind_speed_int= intval($wind_speed);
//echo "$wind_speed_int mph <br>";
$dew = $resp1['currently']['dewPoint'];
//echo "dewPoint: ";
$dew_int= intval($dew);
//echo "$dew_int<br>";
$hum = $resp1['currently']['humidity'];
$hum_percent= $hum*100;

    if(isset ($resp1['currently']['visibility']))
 {
$visi = $resp1['currently']['visibility'];
$visi_int = intval($visi);
 }
       else
       $visi_int = "NA";


$timezone = $resp1['timezone']; 
$sunrise = $resp1['daily']['data'][0]['sunriseTime'];
date_default_timezone_set($timezone);
$sunrise_convert = date('h:i A', $sunrise);


$sunset = $resp1['daily']['data'][0]['sunsetTime'];
date_default_timezone_set($timezone);
$sunset_convert = date('h:i A',$sunset);

?>

<div align="center">  
 <div align="center" style = "border:5px solid black; width: 500px;">
       
<table id= "tableID">
    
    <tr>
        <td><th><center><?php echo $sum; ?></center></th></td>
        
    </tr>
    <tr>
    <td> <th> <center><?php 
if($unit == 'us')
   echo "$temp_int <sup>o</sup>F<br>";
else
    echo"$temp_int <sup>o</sup>C<br>"; ?></center></th></td>
    </tr>
<tr>
    <td>
        <th>
         <center><?php 
switch($ico)
{
    case "clear-day" : echo '<html><img src= "http://cs-server.usc.edu:45678/hw/hw6/images/clear.png" title ="Clear-day"></html>';
        break;
    case "clear-night" : echo '<html><img src= "http://cs-server.usc.edu:45678/hw/hw6/images/clear_night.png" title= "Clear-night"> <alt = "Clear Night"> </html>';
        break;
    case "rain" : echo '<html><img src= "http://cs-server.usc.edu:45678/hw/hw6/images/rain.png" title= "Rain"> <alt = "Rain"> </html>';
        break;
    case "snow" : echo '<html><img src= "http://cs-server.usc.edu:45678/hw/hw6/images/snow.png" title= "Snow"> <alt = "Snow"> </html>';
        break;
    case "sleet" : echo '<html><img src= "http://cs-server.usc.edu:45678/hw/hw6/images/sleet.png" title= "Sleet"> <alt = "Sleet"> </html>';
        break;
    case "wind" : echo '<html><img src= "http://cs-server.usc.edu:45678/hw/hw6/images/wind.png" title= "Wind"> <alt = "Wind"> </html>';
        break;
    case "fog" : echo '<html><img src= "http://cs-server.usc.edu:45678/hw/hw6/images/fog.png" title= "Fog"> <alt = "Fog"> </html>';
        break;
        case "cloudy" : echo '<html><img src= "http://cs-server.usc.edu:45678/hw/hw6/images/cloudy.png" title= "clear"> <alt = "Cloudy"> </html>';
        break;  
    case "partly-cloudy-day" :echo' <html> <img src= "http://cs-server.usc.edu:45678/hw/hw6/images/cloud_day.png"> <alt = "Cloud Day"></html>';
        break;
    case "partly-cloudy-night" : echo '<html><img src= "http://cs-server.usc.edu:45678/hw/hw6/images/cloud_night.png" title= "partly-cloudy-night"> <alt = "Cloud Night"></html>';
        break;
        
    default:
        echo "wrong data";
}
             ?></center></th></td>
</tr>

<tr>
    
<th align="left"> Precipitation</th>
<td></td>
<td align="left"><?php
if($unit == 'us')
{
if($preci >="0" && $preci<"0.002")
    echo "none<br>";
elseif($preci >="0.002" && $preci<"0.017")
    echo "Very Light<br>";
elseif($preci >="0.017" && $preci<"0.1")
    echo "Light<br>";
elseif($preci >="0.1" && $preci<"0.4")
    echo "Moderate<br>";
elseif($preci >="0.4")
    echo "Heavy<br>";
else
    echo "Wrong data";
}
else
   // echo "divide by 25.4";
{
    
 if($preci1 >="0" && $preci1<"0.002")
    echo "none<br>";
elseif($preci1 >="0.002" && $preci1<"0.017")
    echo "Very Light<br>";
elseif($preci1 >="0.017" && $preci1<"0.1")
    echo "Light<br>";
elseif($preci1 >="0.1" && $preci1<"0.4")
    echo "Moderate<br>";
elseif($preci1 >="0.4")
    echo "Heavy<br>";
else
    echo "Wrong data";
    }
?>
</td>
</tr>


<tr>
<th align="left"> 
    Chance of Rain
    
    </th>
    <td></td>
    <td align="left"> <?php echo "$rain_percent %"; ?></td>
</tr>

<tr>
 <th align="left">
        Wind Speed
        
    </th>
    <td>
    </td>
    <td align="left">
    <?php
    if($unit == 'us')
    echo "$wind_speed_int mph";
        else
        echo "$wind_speed_int mps";?>
    </td>
</tr>

<tr>
    <th align="left">
        Dew Point
    
    </th>
    <td></td>
<td align="left">

    <?php 
    if($unit == 'us')
    echo "$dew_int <sup>o</sup>F<br>";
    else
    echo "$dew_int <sup>o</sup>C<br>";
    ?>
    </td></tr>
<tr>
    <th align="left">
        
        Humidity
        
    </th>
    <td>
    </td>
<td align="left">

    <?php echo"$hum_percent %"; ?>
    
</td>
</tr>



<tr>
    <th align="left">
   
        Visibilty
       
    </th>
<td></td>
<td align="left">

    <?php 
    if($unit == 'us')
    echo"$visi_int mi"; 
    else
        echo "$visi_int km";
    ?>
    
</td></tr>
<tr>
    <th align="left">
    
        Sunrise
       </th>
    <td></td>
<td align="left">
    
    <?php echo"$sunrise_convert"; ?>
  
</td></tr>
<tr>
    <th align="left">
    
        Sunset
       </th>
   <td> </td>
<td align="left">
    
    <?php echo"$sunset_convert"; ?>
   
</td></tr>
    </table>
</div>
</div>
</div>

    </body>
</html>
<?php } ?>